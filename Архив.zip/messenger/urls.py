"""messenger URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from main.views import login_redirect

urlpatterns = [
    path('', include('main.urls')),
    path('groups/', include('group.urls')),
    path('chats/', include('chat.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
    path('accounts/profile/', login_redirect, name='login_redirect'),
    path('admin/', admin.site.urls),
]

urlpatterns += staticfiles_urlpatterns()
