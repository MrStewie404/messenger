from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from main.models import Avatars, Updates, Modules, AddedModules, UserSupplement
from django.forms.models import inlineformset_factory

class SignUpForm(UserCreationForm):
    class Meta:
        model = User
        fields = [
            'username',
            'password1',
            'password2',
        ]

class LoginForm(AuthenticationForm):
    class Meta:
        model = User
        fields = [
            'username',
            'password',
        ]

class AvatarForm(forms.ModelForm):
    class Meta:
        model = Avatars
        fields = ['path']

class DescriptionForm(forms.ModelForm):
    class Meta:
        model = UserSupplement
        fields = ['description']

class ModulesChoiceForm(forms.Form):
    def __init__(self, *args, **kwargs):
        queryset = kwargs.pop('queryset', None)
        super().__init__(*args, **kwargs)
        if queryset is not None:
             self.fields['modules'].queryset = queryset

    modules = forms.ModelMultipleChoiceField(
        queryset=AddedModules.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label='Выберите модули'
    )

class ModuleDetailsForm(forms.ModelForm):
    class Meta:
        model = AddedModules
        fields = ['height', 'width', 'visibility_for_others', 'visible']

# ModuleDetailsInlineFormSet = inlineformset_factory(Modules, AddedModules,  
#                                                   form=ModuleDetailsForm,
#                                                   extra=1,
#                                                   can_delete=True)
class ModulesFormSearch(forms.ModelForm):
        class Meta:
           model = Modules
           fields = ['name']

class ModulesFormCreate(forms.ModelForm):
        class Meta:
           model = Modules
           fields = ['name', 'description', 'path', 'visible_in_public']

        # def __init__(self, *args, **kwargs):
        #     super().__init__(*args, **kwargs)
        #     self.module_details_formset = ModuleDetailsInlineFormSet(*args, instance=self.instance, **kwargs)

        # def is_valid(self):
        #     valid = super().is_valid()
        #     return valid and self.module_details_formset.is_valid()

        # def save(self, commit=True):
        #     instance = super().save(commit)
        #     self.module_details_formset.instance = instance
        #     self.module_details_formset.save()
        #     return instance

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name',  'username']


class UpdateForm(forms.ModelForm):
    class Meta:
        model = Updates
        fields = ['title', 'text']