from django import template
from django.utils.html import format_html

register = template.Library()

@register.filter(name='unbox_json')
def unbox_json(value, key):
    return value[key]

@register.simple_tag
def scissors(description, length):
    if description and len(description) > length:
        return format_html('{}...', description[:length])
    return description